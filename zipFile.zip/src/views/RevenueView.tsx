import { TrendingUp, Plus, DollarSign, Wallet, CreditCard, ChevronRight, PieChart } from 'lucide-react';
import { Persona, RevenueEntry } from '../types';

const SAMPLE_ENTRIES: RevenueEntry[] = [
  { id: '1', date: '2023-11-20', amount: 1250, source: 'Brand Deal', platform: 'Instagram', personaId: '1', notes: 'Cyberpunk Clothing Collab' },
  { id: '2', date: '2023-11-18', amount: 450, source: 'Subscription', platform: 'OnlyFans', personaId: '3', notes: 'Monthly renewals' },
  { id: '3', date: '2023-11-15', amount: 320, source: 'Affiliate', platform: 'Amazon', personaId: '1', notes: 'LED gear recommendations' },
];

interface RevenueViewProps {
  persona: Persona;
}

export default function RevenueView({ persona }: RevenueViewProps) {
  const personaEntries = SAMPLE_ENTRIES.filter(e => e.personaId === persona.id);
  const totalPersonaRevenue = personaEntries.reduce((acc, curr) => acc + curr.amount, 0);

  return (
    <div className="p-6">
      <header className="flex justify-between items-center mb-8 pt-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Revenue</h1>
          <p className="text-gray-400 text-sm mt-1">Earnings for {persona.name}</p>
        </div>
        <button className="bg-indigo-600 hover:bg-indigo-500 p-2.5 rounded-full shadow-lg transition-all active:scale-95">
          <Plus size={24} />
        </button>
      </header>

      {/* Summary Card */}
      <div className="bg-indigo-600 rounded-[32px] p-6 mb-8 relative overflow-hidden">
        <div className="absolute top-0 right-0 p-8 opacity-10">
          <TrendingUp size={120} />
        </div>
        <div className="relative z-10">
          <span className="text-indigo-200 text-xs font-bold uppercase tracking-widest">Total Earnings ({persona.name})</span>
          <h2 className="text-4xl font-black mt-2 mb-6 tracking-tight">${totalPersonaRevenue.toLocaleString()}.00</h2>
          
          <div className="grid grid-cols-2 gap-4">
             <div className="bg-white/10 backdrop-blur-md rounded-2xl p-3 border border-white/10">
                <span className="text-[10px] text-indigo-100 block opacity-70 uppercase font-bold">Projected</span>
                <span className="font-bold text-lg">${(totalPersonaRevenue * 1.5).toLocaleString()}</span>
             </div>
             <div className="bg-white/10 backdrop-blur-md rounded-2xl p-3 border border-white/10">
                <span className="text-[10px] text-indigo-100 block opacity-70 uppercase font-bold">Growth</span>
                <span className="font-bold text-lg">+14.2%</span>
             </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4 mb-8">
        <button className="flex flex-col items-center justify-center gap-2 bg-[#1A1A1A] border border-white/5 rounded-3xl p-5 hover:border-indigo-500/30 transition-all group">
          <div className="bg-indigo-500/10 p-3 rounded-2xl group-hover:bg-indigo-500/20 transition-colors">
            <PieChart className="text-indigo-400" size={24} />
          </div>
          <span className="text-sm font-medium">By Persona</span>
        </button>
        <button className="flex flex-col items-center justify-center gap-2 bg-[#1A1A1A] border border-white/5 rounded-3xl p-5 hover:border-indigo-500/30 transition-all group">
          <div className="bg-indigo-500/10 p-3 rounded-2xl group-hover:bg-indigo-500/20 transition-colors">
            <Wallet className="text-indigo-400" size={24} />
          </div>
          <span className="text-sm font-medium">Withdraw</span>
        </button>
      </div>

      <div className="space-y-4">
        <div className="flex justify-between items-center mb-2 px-1">
          <h3 className="font-bold text-lg">Transactions</h3>
          <button className="text-indigo-400 text-xs font-bold uppercase tracking-wider">See All</button>
        </div>

        {personaEntries.length > 0 ? personaEntries.map((entry) => (
          <div key={entry.id} className="bg-[#1A1A1A] border border-white/5 rounded-2xl p-4 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="bg-white/5 p-3 rounded-xl border border-white/5">
                {entry.source === 'Brand Deal' ? <CreditCard size={20} className="text-indigo-400" /> : <DollarSign size={20} className="text-green-400" />}
              </div>
              <div>
                <h4 className="font-bold text-sm">{entry.source}</h4>
                <p className="text-[11px] text-gray-500">{entry.platform} • {entry.date}</p>
              </div>
            </div>
            <div className="text-right">
              <span className="font-black text-sm text-white">+${entry.amount}</span>
              <ChevronRight size={14} className="text-gray-700 ml-auto mt-1" />
            </div>
          </div>
        )) : (
          <div className="text-center py-10 bg-[#1A1A1A] rounded-2xl border border-white/5">
            <p className="text-gray-500 text-sm italic">No entries for this persona yet.</p>
          </div>
        )}
      </div>
    </div>
  );
}
